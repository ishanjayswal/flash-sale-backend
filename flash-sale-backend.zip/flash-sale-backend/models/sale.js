const mongoose = require('mongoose');

const saleSchema = new mongoose.Schema({
    item: { type: mongoose.Schema.Types.ObjectId, ref: 'Item' },
    startTime: Date,
    endTime: Date,
    status: { type: String, default: 'upcoming' }
});

module.exports = mongoose.model('Sale', saleSchema);
