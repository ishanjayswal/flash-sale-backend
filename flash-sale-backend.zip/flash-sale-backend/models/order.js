const mongoose = require('mongoose');

const orderSchema = new mongoose.Schema({
    customerId: String,
    item: { type: mongoose.Schema.Types.ObjectId, ref: 'Item' },
    quantity: Number,
    orderTime: Date
});

module.exports = mongoose.model('Order', orderSchema);
