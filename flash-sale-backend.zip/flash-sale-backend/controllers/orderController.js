const Sale = require('../models/sale');
const Order = require('../models/order');
const Item = require('../models/item');

exports.createOrder = async (req, res) => {
    const session = await Order.startSession();
    session.startTransaction();

    try {
        const { saleId, customerId, quantity } = req.body;
        const sale = await Sale.findById(saleId).populate('item');
        const item = sale.item;

        if (sale.status !== 'active' || item.remainingStock < quantity) {
            await session.abortTransaction();
            return res.status(400).send('Item out of stock or sale not active');
        }

        item.remainingStock -= quantity;
        await item.save({ session });

        const order = new Order({
            customerId,
            item: item._id,
            quantity,
            orderTime: new Date()
        });

        await order.save({ session });
        await session.commitTransaction();
        res.json(order);
    } catch (error) {
        await session.abortTransaction();
        res.status(500).send(error);
    } finally {
        session.endSession();
    }
};
