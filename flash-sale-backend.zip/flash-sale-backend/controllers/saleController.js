const Sale = require('../models/sale');
const Item = require('../models/item');

exports.createSale = async (req, res) => {
    try {
        const { itemId, startTime } = req.body;
        const item = await Item.findById(itemId);

        if (!item) {
            return res.status(404).send('Item not found');
        }

        const sale = new Sale({
            item: itemId,
            startTime,
            endTime: null, // to be updated when sale ends
            status: 'upcoming'
        });

        await sale.save();
        res.json(sale);
    } catch (error) {
        res.status(500).send(error);
    }
};

exports.getSale = async (req, res) => {
    try {
        const sale = await Sale.findById(req.params.saleId).populate('item');
        res.json(sale);
    } catch (error) {
        res.status(500).send(error);
    }
};
