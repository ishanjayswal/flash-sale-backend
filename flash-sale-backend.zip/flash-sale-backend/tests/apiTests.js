const chai = require('chai');
const chaiHttp = require('chai-http');
const app = require('../app'); // make sure to export app in app.js

chai.should();
chai.use(chaiHttp);

describe('API Testing', () => {
    it('should GET all the items', (done) => {
        chai.request(app)
            .get('/api/items')
            .end((err, res) => {
                res.should.have.status(200);
                res.body.should.be.a('array');
                done();
            });
    });

    // Add more tests here...
});
