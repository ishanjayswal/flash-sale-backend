const express = require('express');
const mongoose = require('mongoose');
const dotenv = require('dotenv');

const itemRoutes = require('./routes/itemRoutes');
const saleRoutes = require('./routes/saleRoutes');
const orderRoutes = require('./routes/orderRoutes');

dotenv.config();

const app = express();

// MongoDB connection using updated code (removing deprecated options)
mongoose.connect(process.env.MONGO_URI)
  .then(() => console.log('Connected to MongoDB'))
  .catch(err => console.log(err));

app.use(express.json());

// Root route
app.get('/', (req, res) => {
  res.send('Flash Sale Backend is running');
});

// API routes
app.use('/api', itemRoutes);
app.use('/api', saleRoutes);
app.use('/api', orderRoutes);

const port = process.env.PORT || 3000;
app.listen(port, () => console.log(`Server running on port ${port}`));
